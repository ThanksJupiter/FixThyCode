﻿using UnityEngine;

public class SphereCollision : MonoBehaviour
{
    const float g = 10f;
    public bool useGravity = true;
    public float wallLength = 5f;

    public GameObject boxGO;

    public PlaneGO p0;
    public PlaneGO p1;
    public PlaneGO p2;
    public PlaneGO p3;

    [SerializeField] SphereRenderer sRen = new SphereRenderer();
    Vector3 point = Vector3.zero;

    [SerializeField] int sphereAmount;
    SphereData[] sphereDatas = new SphereData[1023];

    public class SphereData
    {
        public SphereData(int index, Vector3 position)
        {
            this.index = index;
            radius = .5f;
            velocity = Vector3.zero;
            acceleration = Vector3.zero;
            this.position = position;
        }

        public int index;
        public float radius;
        public Vector3 acceleration;
        public Vector3 velocity;
        public Vector3 position;

        public static bool operator ==(SphereData s0, SphereData s1)
        {
            return s0.index == s1.index;
        }

        public static bool operator !=(SphereData s0, SphereData s1)
        {
            return s0.index != s1.index;
        }
    }

    private void Start()
    {
        AddSphere(Vector3.up * 2f);
    }

    void AddSphere(Vector3 position)
    {
        sRen.AddSphere(position);
        sphereDatas[sphereAmount] = new SphereData(sphereAmount, position);
        sphereAmount++;
    }

    bool AreSpheresColliding(SphereData s0, SphereData s1)
    {
        float x = s0.position.x - s1.position.x;
        float y = s0.position.y - s1.position.y;
        float centerDstSq = x * x + y * y;
        float radius = s0.radius + s1.radius;
        float radiusSq = radius * radius;
        return centerDstSq <= radiusSq;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            AddSphere(Vector3.up * 2f);
        }

        if (Input.GetKey(KeyCode.G))
        {
            AddSphere(Vector3.up);
            AddSphere(Vector3.up * .1f);
            AddSphere(Vector3.up * .2f);
            AddSphere(Vector3.up * .3f);
            AddSphere(Vector3.up * .4f);
            AddSphere(Vector3.up * .5f);
            AddSphere(Vector3.up * .6f);
            AddSphere(Vector3.up * .7f);
            AddSphere(Vector3.up * .8f);
            AddSphere(Vector3.up * .9f);
            AddSphere(Vector3.up * 1f);
        }

        sRen.RenderSpheres();
    }

    private void FixedUpdate()
    {
        for (int i = 0; i < sphereAmount; i++)
        {
            Simulate(sphereDatas[i]);
        }

        // TODO split these loops into two to not have spheres update position before checking every combination
        for (int i = 0; i < sphereAmount; i++)
        {
            UpdateSpherePosition(sphereDatas[i]);
        }
    }

    private Vector3 CollisionResolutionVector(SphereData s, PlaneGO p)
    {
        Vector3 circToPlane = (p.position + p.normal * (s.radius - .01f)) - s.position;
        Vector3 dir = p.normal * Vector3.Dot(circToPlane, p.normal);
        float dot = Vector3.Dot(dir, p.normal);

        bool r = dot < 0f;

        if (r)
        {
            return Vector3.zero;
        }
        else
        {
            return p.normal * Mathf.Abs(dot);
        }
    }

    void Simulate(SphereData s)
    {
        s.acceleration = useGravity ? -Vector3.up * g : Vector3.zero;
        s.velocity += s.acceleration * Time.fixedDeltaTime;

        Vector3 force = Vector3.zero;

        // floor reflect if gravity is not used, otherwise counter force
        force += NormalForce(s, p0) * (useGravity? Mathf.Abs(s.velocity.y) : s.velocity.magnitude);

        // if colliding with walls
        force += NormalForce(s, p1) * Mathf.Abs(s.velocity.magnitude);
        force += NormalForce(s, p2) * Mathf.Abs(s.velocity.magnitude);
        force += NormalForce(s, p3) * Mathf.Abs(s.velocity.magnitude);

        // elastic collisions between spheres
        // TODO start at current sphere index to not loop through as many combinations that have been checked earlier
        for (int i = s.index; i < sphereAmount; i++)
        {
            if (s == sphereDatas[i])
            {
                continue;
            }

            if (AreSpheresColliding(s, sphereDatas[i]))
            {
                Vector3 sphereDir = s.position - sphereDatas[i].position;
                s.velocity += sphereDir;
                sphereDatas[i].velocity -= sphereDir;
            }
        }

        s.velocity += force;
    }

    void UpdateSpherePosition(SphereData s)
    {        
        s.position += s.velocity * Time.fixedDeltaTime;

        // if outside of walls
        s.position += CollisionResolutionVector(s, p0);
        s.position += CollisionResolutionVector(s, p1);
        s.position += CollisionResolutionVector(s, p2);
        s.position += CollisionResolutionVector(s, p3);

        sRen.UpdateSpherePosition(s.index, s.position);
    }

    private Vector3 NormalForce(SphereData s, PlaneGO p)
    {
        Vector3 circToPlane = p.position - (s.position + -p.normal * s.radius);

        float dot = Vector3.Dot(circToPlane, p.normal);
        Vector3 dir = p.normal * dot;

        if (dot < 0)
        {
            return Vector3.zero;
        }

        return dir.normalized;
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawRay(p0.position, p0.right * wallLength);
        Gizmos.DrawRay(p0.position, p0.right * -wallLength);

        Gizmos.DrawRay(p1.position, p1.right * wallLength);
        Gizmos.DrawRay(p1.position, p1.right * -wallLength);

        Gizmos.DrawRay(p2.position, p2.right * wallLength);
        Gizmos.DrawRay(p2.position, p2.right * -wallLength);

        Gizmos.DrawRay(p3.position, p3.right * wallLength);
        Gizmos.DrawRay(p3.position, p3.right * -wallLength);
    }
}
