﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewtCrad : MonoBehaviour
{
    [SerializeField] Vector3 origin = Vector3.up * 3f + Vector3.left * 12f;

    [SerializeField] Sphere s;

    [SerializeField] float l = 2f;
    [SerializeField] float correctiveForce = 1f;

    Vector3 desiredPos = Vector3.zero;

    void FixedUpdate()
    {
        Simulate();
    }

    void Simulate()
    {
        s.acceleration = Vector3.down * 10f;

        s.velocity += s.acceleration * Time.fixedDeltaTime;

        Vector3 dir = origin - s.position;
        desiredPos = origin - dir.normalized * l;
        //Vector3 dirToCirc = 
        float dot = Vector3.Dot(s.velocity, dir);

        Vector3 add = dir.normalized * Mathf.Abs(dot);
        s.velocity += add * s.velocity.magnitude * Time.fixedDeltaTime;
        Debug.DrawRay(s.position, add, Color.blue);
        s.position += s.velocity * Time.fixedDeltaTime;
    }

    void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawLine(origin, s.position);

        Gizmos.DrawWireSphere(origin, .4f);

        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(desiredPos, .4f);
    }
}

/*
Vector3 circToPlane = p.position - (s.position + -p.normal * s.radius);

float dot = Vector3.Dot(circToPlane, p.normal);
Vector3 dir = p.normal * dot;

        if (dot< 0)
        {
            return Vector3.zero;
        }

        return dir.normalized;
*/
