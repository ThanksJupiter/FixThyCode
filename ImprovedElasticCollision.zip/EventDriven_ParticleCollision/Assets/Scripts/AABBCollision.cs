﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AABBCollision : MonoBehaviour
{
    class AABB
    {
        public Vector3 position = Vector3.zero;
        public Vector2 min;
        public Vector2 max;

        public float extX = 2f;
        public float extY = 1f;

        public void CalcMinMax()
        {
            min.x = position.x - extX;
            min.y = position.y - extY;

            max.x = position.x + extX;
            max.y = position.y + extY;
        }
    }

    public bool showCubes = false;
    public float speed = 5f;

    AABB a = new AABB();
    AABB b = new AABB();

    void Start()
    {
        b.position = new Vector3(3f, 0f, 0f);
        b.CalcMinMax();
    }

    void Update()
    {
        if (!showCubes) return;

        float movementX = Input.GetKey(KeyCode.D) ? speed : Input.GetKey(KeyCode.A) ? -speed : 0f;
        a.position.x += movementX * Time.deltaTime;
        float movementY = Input.GetKey(KeyCode.W) ? speed : Input.GetKey(KeyCode.S) ? -speed : 0f;
        a.position.y += movementY * Time.deltaTime;

        float bMovementX = Input.GetKey(KeyCode.RightArrow) ? speed : Input.GetKey(KeyCode.LeftArrow) ? -speed : 0f;
        b.position.x += bMovementX * Time.deltaTime;
        float bMovementY = Input.GetKey(KeyCode.UpArrow) ? speed : Input.GetKey(KeyCode.DownArrow) ? -speed : 0f;
        b.position.y += bMovementY * Time.deltaTime;

        a.CalcMinMax();
        b.CalcMinMax();
    }

    bool TestAABBOverlap(AABB a, AABB b)
    {
        float d1x = b.min.x - a.max.x;
        float d1y = b.min.y - a.max.y;
        float d2x = a.min.x - b.max.x;
        float d2y = a.min.y - b.max.y;

        if (d1x > 0f || d1y > 0f)
        {
            return false;
        }

        if (d2x > 0f || d2y > 0f)
        {
            return false;
        }

        return true;
    }

    void OnDrawGizmos()
    { if (!Application.isPlaying) return;

        if (!showCubes) return;

        Gizmos.color = TestAABBOverlap(a, b) ? Color.red : Color.green;
        Gizmos.DrawWireCube(a.position, new Vector3(a.extX, a.extY, 0f) * 2f);
        Gizmos.DrawWireCube(b.position, new Vector3(b.extX, b.extY, 0f) * 2f);
    }
}
