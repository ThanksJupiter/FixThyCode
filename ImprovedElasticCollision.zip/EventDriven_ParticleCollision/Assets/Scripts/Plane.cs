﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Plane
{
    public Plane(float extents, Vector3 position, Vector3 normal)
    {
        this.extents = extents;
        this.position = position;
        this.normal = normal;
    }

    public float extents = 5f;
    public Vector3 position = Vector3.zero;
    public Vector3 normal = Vector3.up;
}
