﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class BezierCollision : MonoBehaviour
{
    public bool moveFloor = false;

    [SerializeField] Vector3 p1, pc, p2;
    [SerializeField] const int segments = 6;
    float[] t = { 0f, .2f, .4f, .6f, .8f, 1f };

    [HideInInspector] public Plane[] planes;

    private void Awake()
    {
        planes = new Plane[segments];

        for (int i = 0; i < segments; i++)
        {
            planes[i] = new Plane(5f, GetPointAt(t[i], p1, pc, p2), GetNormalAt(t[i], p1, pc, p2));
        }
    }

    private void Update()
    {
        if (moveFloor)
        {
            pc.y = -4f + Mathf.Cos(Time.time) * .9f;

            for (int i = 0; i < segments; i++)
            {
                planes[i] = new Plane(5f, GetPointAt(t[i], p1, pc, p2), GetNormalAt(t[i], p1, pc, p2));
            }
        }
    }

    Vector3 GetPointAt(float t, Vector3 p1, Vector3 pc, Vector3 p2)
    {
        float x = (1 - t) * (1 - t) * p1.x + 2 * (1 - t) * t * pc.x + t * t * p2.x;
        float y = (1 - t) * (1 - t) * p1.y + 2 * (1 - t) * t * pc.y + t * t * p2.y;

        return new Vector3(x, y, 0f);
    }

    Vector3 GetDerivativeAt(float t, Vector3 p1, Vector3 pc, Vector3 p2)
    {
        Vector2 d1 = new Vector2(
            2 * (pc.x - p1.x), 2 * (pc.y - p1.y));

        Vector2 d2 = new Vector2(
            2 * (p2.x - pc.x), 2 * (p2.y - pc.y));

        float x = (1 - t) * d1.x + t * d2.x;
        float y = (1 - t) * d1.y + t * d2.y;

        return new Vector3(x, y, 0f);
    }

    Vector3 GetNormalAt(float t, Vector3 p1, Vector3 pc, Vector3 p2)
    {
        Vector3 d = GetDerivativeAt(t, p1, pc, p2);
        float q = Mathf.Sqrt(d.x * d.x + d.y * d.y);

        float x = -d.y / q;
        float y = d.x / q;

        return new Vector3(x, y, 0f);
    }

    private void OnDrawGizmos()
    {
        for (int i = 0; i < segments; i++)
        {
            if (i == segments - 1)
            {
                Gizmos.DrawLine(GetPointAt(t[i], p1, pc, p2), p2);
            }
            else
            {
                Gizmos.DrawLine(GetPointAt(t[i], p1, pc, p2), GetPointAt(t[i + 1], p1, pc, p2));
            }
        }
    }
}
