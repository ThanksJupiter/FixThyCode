﻿using UnityEngine;

// TODO Render spheres using DrawMeshInstanced instead of having gameobjects
[System.Serializable]
public class SphereRenderer
{
    const int MAX_SPHERES = 1023;

    public Mesh mesh;
    public Material material;
    public Vector3 scale = Vector3.one;

    public Matrix4x4[] matrices = new Matrix4x4[MAX_SPHERES];
    private int currentSphereAmount = 0;

    public void RenderSpheres()
    {
        Graphics.DrawMeshInstanced(mesh, 0, material, matrices);
    }

    public void AddSphere(Vector3 position)
    {
        Quaternion rot = Quaternion.identity;
        matrices[currentSphereAmount].SetTRS(position, rot, scale);
        currentSphereAmount++;
        if (currentSphereAmount == MAX_SPHERES)
        {
            currentSphereAmount = 0;
        }
    }

    public void UpdateSpherePosition(int index, Vector3 position)
    {
        matrices[index].SetTRS(position, Quaternion.identity, scale);
    }
}
