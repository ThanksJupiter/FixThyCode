﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaneGO : MonoBehaviour
{
    public float extents = 5f;

    private Vector3 _position;
    private Vector3 _normal;
    private Vector3 _right;

    // caching variables here instead of getting transform.position/up/right improved performance
    void Awake()
    {
        _position = transform.position;
        _normal = transform.up;
        _right = transform.right;
    }

    public Vector3 position
    {
        get
        {
            return _position;
        }
    }
    public Vector3 normal
    {
        get
        {
            return _normal;
        }
    }
    public Vector3 right
    {
        get
        {
            return _right;
        }
    }
}
